# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(interop-tests src/interop-tests.cpp)
set_property(TARGET interop-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(interop-tests lionss pthread)

add_executable(locale-tests src/locale-tests.cpp)
set_property(TARGET locale-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(locale-tests lionss pthread)

add_executable(branch-prediction src/branch-prediction.cpp)
set_property(TARGET branch-prediction PROPERTY CXX_STANDARD 11)
target_link_libraries(branch-prediction lionss pthread)

add_executable(macos-arm64 src/macos-arm64.cpp)
set_property(TARGET macos-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-arm64 lionss pthread)

add_executable(codeql src/codeql.cpp)
set_property(TARGET codeql PROPERTY CXX_STANDARD 11)
target_link_libraries(codeql lionss pthread)

add_executable(linux-loongarch64 src/linux-loongarch64.cpp)
set_property(TARGET linux-loongarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-loongarch64 lionss pthread)

add_executable(lizard-complexity src/lizard-complexity.cpp)
set_property(TARGET lizard-complexity PROPERTY CXX_STANDARD 11)
target_link_libraries(lizard-complexity lionss pthread)

add_executable(dependency-graph src/dependency-graph.cpp)
set_property(TARGET dependency-graph PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-graph lionss pthread)

add_executable(bandwidth-bench src/bandwidth-bench.cpp)
set_property(TARGET bandwidth-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(bandwidth-bench lionss pthread)

add_executable(wheel-build src/wheel-build.cpp)
set_property(TARGET wheel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wheel-build lionss pthread)

add_executable(linux-aarch64 src/linux-aarch64.cpp)
set_property(TARGET linux-aarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-aarch64 lionss pthread)

add_executable(readme-render src/readme-render.cpp)
set_property(TARGET readme-render PROPERTY CXX_STANDARD 11)
target_link_libraries(readme-render lionss pthread)

add_executable(semver-check src/semver-check.cpp)
set_property(TARGET semver-check PROPERTY CXX_STANDARD 11)
target_link_libraries(semver-check lionss pthread)

add_executable(clang-trunk src/clang-trunk.cpp)
set_property(TARGET clang-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-trunk lionss pthread)

add_executable(windows-x86 src/windows-x86.cpp)
set_property(TARGET windows-x86 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-x86 lionss pthread)

add_executable(codechecker src/codechecker.cpp)
set_property(TARGET codechecker PROPERTY CXX_STANDARD 11)
target_link_libraries(codechecker lionss pthread)

add_executable(pin-dependencies src/pin-dependencies.cpp)
set_property(TARGET pin-dependencies PROPERTY CXX_STANDARD 11)
target_link_libraries(pin-dependencies lionss pthread)

add_executable(microbench src/microbench.cpp)
set_property(TARGET microbench PROPERTY CXX_STANDARD 11)
target_link_libraries(microbench lionss pthread)

add_executable(safestack src/safestack.cpp)
set_property(TARGET safestack PROPERTY CXX_STANDARD 11)
target_link_libraries(safestack lionss pthread)

add_executable(snapshot-tests src/snapshot-tests.cpp)
set_property(TARGET snapshot-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(snapshot-tests lionss pthread)

add_executable(serialization-tests src/serialization-tests.cpp)
set_property(TARGET serialization-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(serialization-tests lionss pthread)

add_executable(latency-bench src/latency-bench.cpp)
set_property(TARGET latency-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(latency-bench lionss pthread)

add_executable(freebsd-build src/freebsd-build.cpp)
set_property(TARGET freebsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(freebsd-build lionss pthread)

add_executable(fuzz-regression src/fuzz-regression.cpp)
set_property(TARGET fuzz-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-regression lionss pthread)

add_executable(unity-build src/unity-build.cpp)
set_property(TARGET unity-build PROPERTY CXX_STANDARD 11)
target_link_libraries(unity-build lionss pthread)

add_executable(build-relwithdebinfo src/build-relwithdebinfo.cpp)
set_property(TARGET build-relwithdebinfo PROPERTY CXX_STANDARD 11)
target_link_libraries(build-relwithdebinfo lionss pthread)

add_executable(headless-tests src/headless-tests.cpp)
set_property(TARGET headless-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(headless-tests lionss pthread)

add_executable(haiku-build src/haiku-build.cpp)
set_property(TARGET haiku-build PROPERTY CXX_STANDARD 11)
target_link_libraries(haiku-build lionss pthread)

add_executable(fortify-source src/fortify-source.cpp)
set_property(TARGET fortify-source PROPERTY CXX_STANDARD 11)
target_link_libraries(fortify-source lionss pthread)

add_executable(gcc-oldest src/gcc-oldest.cpp)
set_property(TARGET gcc-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-oldest lionss pthread)

