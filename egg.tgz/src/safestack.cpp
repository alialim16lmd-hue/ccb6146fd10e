// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("safestack\n", stdout);
  return lionss_run_workload("safestack");
}
