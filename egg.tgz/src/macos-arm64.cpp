// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("macos arm64\n", stdout);
  return lionss_run_workload("macos-arm64");
}
